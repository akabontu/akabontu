<?php if (!defined('IN_DASHBOARD')): ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Tambah Product</title>
  <link rel="stylesheet" href="../../../assets/css/style.css">
</head>
<body>
<?php // header removed: managed by menu_admin shell ?>
<?php endif; ?>
<?php
include(__DIR__ . '/../../../System/kon.php');

// Tambah: autoload PhpSpreadsheet jika ada
if (file_exists(__DIR__ . '/../../../../vendor/autoload.php')) {
    require_once __DIR__ . '/../../../../vendor/autoload.php';
}
$errors = [];
// Flag to focus part_number after import submission
$focusPartNumber = false;

// Create product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
        $part_number = trim($_POST['part_number'] ?? '');
        $itc = trim($_POST['itc'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $brand = trim($_POST['brand'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $qty = intval($_POST['qty'] ?? 0);
        $brt = intval($_POST['berat'] ?? 0);

        if ($part_number === '') $errors[] = 'Part number harus diisi.';
        if ($brand === '') $errors[] = 'Brand harus diisi.';
        if ($category === '') $errors[] = 'Category harus diisi.';
        // Qty boleh kosong, default 0

        // Whitelist validation for brand and category
        $allowed_brands = ['Komatsu','Bomag','Caterpillar','Scania','Volvo','Hyva','Other'];
        $allowed_categories = [
            'Engine','Electrical','Brake System','Cylinder','Axle & Stering','Cabin','Filter','Attachment','Final Drive','Hydraulic System'
        ];
        if ($brand !== '' && !in_array($brand, $allowed_brands)) $errors[] = 'Brand tidak valid.';
        if ($category !== '' && !in_array($category, $allowed_categories)) $errors[] = 'Category tidak valid.';

        $imageData = null;
        if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['image'];
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            $allowed = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($mime, $allowed)) $errors[] = 'Tipe file tidak didukung.';
            elseif ($file['size'] > 3 * 1024 * 1024) $errors[] = 'Ukuran file melebihi 3MB.';
            else { $imageData = file_get_contents($file['tmp_name']); }
        }

        if (empty($errors)) {
                try {
                        if ($imageData !== null) {
                          $stmt = mysqli_prepare($kon, "INSERT INTO Product (part_number, itc, description, brand, category, Qty,berat, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                          mysqli_stmt_bind_param($stmt, "sssssiss", $part_number, $itc, $description, $brand, $category, $qty, $brt, $imageData);
                          mysqli_stmt_execute($stmt);
                          mysqli_stmt_close($stmt);
                        } else {
                          $stmt = mysqli_prepare($kon, "INSERT INTO Product (part_number, itc, description, brand, category, Qty, berat) VALUES (?, ?, ?, ?, ?, ?, ?)");
                          mysqli_stmt_bind_param($stmt, "sssssis", $part_number, $itc, $description, $brand, $category, $qty, $brt);
                          mysqli_stmt_execute($stmt);
                          mysqli_stmt_close($stmt);
                        }
                        // Perbaiki: insert ke itc_pn hanya jika part_number, itc, dan description tidak kosong
                        if ($part_number !== '' && $itc !== '' && $description !== '') {
                          $stmt2 = mysqli_prepare($kon, "INSERT INTO itc_pn (part_number, itc, description) VALUES (?, ?, ?)");
                          if ($stmt2) {
                            mysqli_stmt_bind_param($stmt2, "sss", $part_number, $itc, $description);
                            if (!mysqli_stmt_execute($stmt2)) {
                              $errors[] = 'Gagal menyimpan itc_pn: ' . mysqli_stmt_error($stmt2);
                            }
                            mysqli_stmt_close($stmt2);
                          } else {
                            $errors[] = 'Prepare itc_pn gagal: ' . mysqli_error($kon);
                          }
                        }
                        $ok = true;
                } catch (mysqli_sql_exception $e) {
                        if ($e->getCode() == 1062) {
                                $errors[] = 'Part number sudah ada, silakan gunakan yang berbeda.';
                        } else {
                                $errors[] = 'Gagal menyimpan: ' . $e->getMessage();
                        }
                        $ok = false;
                }
                if (!empty($ok)) {
                        echo '<div id="success-msg" class="card" style="border-left:4px solid #27ae60;margin-bottom:12px;"><div style="color:#155724;padding:6px 0">Produk berhasil ditambahkan!</div></div>';
                        echo '<script>document.getElementById("part_number").focus(); document.getElementById("part_number").value = ""; document.getElementById("itc").value = ""; document.getElementById("description").value = ""; document.getElementById("brand").value = ""; document.getElementById("category").value = ""; document.getElementById("qty").value = ""; setTimeout(() => { document.getElementById("success-msg").style.display = "none"; }, 500);</script>';
                        // header('Location: admin_dashboard.php?menu=product'); exit;
                }
        }
}

// Simple CSV/Excel import: expected order part_number,itc,description,brand,category,qty
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import'])) {
  // ensure we focus the part_number input when the page reloads after import
  $focusPartNumber = true;
  if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $errors[] = 'Pilih file CSV atau Excel.';
  } else {
    $tmp = $_FILES['file']['tmp_name'];
    $filename = $_FILES['file']['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if ($ext === 'csv') {
      if (($h = fopen($tmp, 'r')) !== false) {
        $row = 0;
        $importErrors = [];
        $importedCount = 0;
        while (($r = fgetcsv($h, 0, ',')) !== false) {
          $row++;
          // treat first row as header if it contains known header tokens
          if ($row === 1) {
            $cells = array_map(function($c){ return strtolower(trim((string)$c)); }, $r);
            $known = ['part_number','part number','pn','part','itc','description','brand','category','qty','quantity','name','nama'];
            $isHeader = false;
            foreach ($cells as $c) { if ($c !== '' && in_array($c, $known, true)) { $isHeader = true; break; } }
            if ($isHeader) continue; // skip header row
          }
          $pn = trim($r[0] ?? '');
          $itc = trim($r[1] ?? '');
          $desc = trim($r[2] ?? '');
          $brand = trim($r[3] ?? '');
          $cat = trim($r[4] ?? '');
          $qty = intval($r[5] ?? 0);
          $brt = intval($r[6] ?? 0);
          if ($pn === '') continue;

          $allowed_brands = ['Komatsu','Bomag','Caterpillar','Scania','Volvo','Hyva','Other'];
          $allowed_categories = [
            'Engine','Electrical','Brake System','Cylinder','Axle & Stering','Cabin','Filter','Attachment','Final Drive','Hydraulic System'
          ];

          // For imports be permissive: fill missing values and accept unknown brands/categories.
          if ($brand === '') $brand = 'Other';
          if ($cat === '') $cat = 'Other';

          // Validate brand and category
          if (!in_array($brand, $allowed_brands)) {
            $importErrors[] = "Row $row: Brand '$brand' tidak valid. Menggunakan 'Other'.";
            $brand = 'Other';
          }
          if (!in_array($cat, $allowed_categories)) {
            $importErrors[] = "Row $row: Category '$cat' tidak valid. Menggunakan 'Other'.";
            $cat = 'Other';
          }

          // Check if part_number already exists
          $check = mysqli_prepare($kon, "SELECT 1 FROM Product WHERE part_number = ?");
          mysqli_stmt_bind_param($check, "s", $pn);
          mysqli_stmt_execute($check);
          mysqli_stmt_bind_result($check, $exists);
          if (mysqli_stmt_fetch($check)) {
            $importErrors[] = "Row $row: Part number '$pn' sudah ada.";
            mysqli_stmt_close($check);
            continue;
          }
          mysqli_stmt_close($check);

          $stmt = mysqli_prepare($kon, "INSERT INTO Product (part_number, itc, description, brand, category, Qty, berat) VALUES (?, ?, ?, ?, ?, ?, ?)");
          if (!$stmt) { $importErrors[] = "Row $row: prepare failed: " . mysqli_error($kon); continue; }
          mysqli_stmt_bind_param($stmt, 'sssssis', $pn, $itc, $desc, $brand, $cat, $qty, $brt);
          if (!mysqli_stmt_execute($stmt)) { $importErrors[] = "Row $row: insert product failed: " . mysqli_stmt_error($stmt); }
          mysqli_stmt_close($stmt);

          if ($pn !== '' && $itc !== '' && $desc !== '') {
            $stmt2 = mysqli_prepare($kon, "INSERT IGNORE INTO itc_pn (part_number, itc, description) VALUES (?, ?, ?)");
            if (!$stmt2) { $importErrors[] = "Row $row: prepare itc_pn failed: " . mysqli_error($kon); continue; }
            mysqli_stmt_bind_param($stmt2, "sss", $pn, $itc, $desc);
            if (!mysqli_stmt_execute($stmt2)) { $importErrors[] = "Row $row: insert itc_pn failed: " . mysqli_stmt_error($stmt2); }
            mysqli_stmt_close($stmt2);
          }

          $importedCount++;
        }
        fclose($h);
        if (empty($importErrors)) {
          echo '<div id="success-msg" class="card" style="border-left:4px solid #27ae60;margin-bottom:12px;"><div style="color:#155724;padding:6px 0">Import berhasil! ' . $importedCount . ' produk telah ditambahkan.</div></div>';
          echo '<script>document.getElementById("part_number").focus(); setTimeout(() => { document.getElementById("success-msg").style.display = "none"; }, 5000);</script>';
        } else {
          $errors[] = 'Import selesai dengan ' . count($importErrors) . ' error. ' . $importedCount . ' produk berhasil diimport. Error: ' . implode('; ', array_slice($importErrors,0,3));
        }
      } else {
        $errors[] = 'Gagal membuka file CSV.';
      }
    } elseif ($ext === 'xls' || $ext === 'xlsx') {
      if (!class_exists('\PhpOffice\PhpSpreadsheet\IOFactory')) {
        $errors[] = 'PhpSpreadsheet tidak terpasang. Gunakan file CSV atau install package phpoffice/phpspreadsheet via Composer.';
      } else {
      try {
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($tmp);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();
        $row = 0;
        $importErrors = [];
        $importedCount = 0;
        foreach ($rows as $r) {
          $row++;
          if ($row === 1) {
            $cells = array_map(function($c){ return strtolower(trim((string)$c)); }, $r);
            $known = ['part_number','part number','pn','part','itc','description','brand','category','qty','quantity','name','nama'];
            $isHeader = false;
            foreach ($cells as $c) { if ($c !== '' && in_array($c, $known, true)) { $isHeader = true; break; } }
            if ($isHeader) continue;
          }
          $pn = trim($r[0] ?? '');
          $itc = trim($r[1] ?? '');
          $desc = trim($r[2] ?? '');
          $brand = trim($r[3] ?? '');
          $cat = trim($r[4] ?? '');
          $qty = intval($r[5] ?? 0);

          // Skip empty part numbers
          if ($pn === '') continue;

          $allowed_brands = ['Komatsu','Bomag','Caterpillar','Scania','Volvo','Hyva','Other'];
          $allowed_categories = [
            'Engine','Electrical','Brake System','Cylinder','Axle & Stering','Cabin','Filter','Attachment','Final Drive','Hydraulic System'
          ];

          // For imports be permissive: fill missing values and accept unknown brands/categories.
          if ($brand === '') $brand = 'Other';
          if ($cat === '') $cat = 'Other';

          // Validate brand and category
          if (!in_array($brand, $allowed_brands)) {
            $importErrors[] = "Row $row: Brand '$brand' tidak valid. Menggunakan 'Other'.";
            $brand = 'Other';
          }
          if (!in_array($cat, $allowed_categories)) {
            $importErrors[] = "Row $row: Category '$cat' tidak valid. Menggunakan 'Other'.";
            $cat = 'Other';
          }

          // Check if part_number already exists
          $check = mysqli_prepare($kon, "SELECT 1 FROM Product WHERE part_number = ?");
          mysqli_stmt_bind_param($check, "s", $pn);
          mysqli_stmt_execute($check);
          mysqli_stmt_bind_result($check, $exists);
          $duplicate = mysqli_stmt_fetch($check);
          mysqli_stmt_close($check);

          if ($duplicate) {
            $importErrors[] = "Row $row: Part number '$pn' sudah ada.";
            continue;
          }

          $stmt = mysqli_prepare($kon, "INSERT INTO Product (part_number, itc, description, brand, category, Qty) VALUES (?, ?, ?, ?, ?, ?)");
          if (!$stmt) { $importErrors[] = "Row $row: prepare failed: " . mysqli_error($kon); continue; }
          mysqli_stmt_bind_param($stmt, 'sssssi', $pn, $itc, $desc, $brand, $cat, $qty);
          if (!mysqli_stmt_execute($stmt)) { $importErrors[] = "Row $row: insert product failed: " . mysqli_stmt_error($stmt); }
          mysqli_stmt_close($stmt);
          // Jika itc tidak kosong, masukkan ke itc_pn
          if ($itc !== ''){
            $stmt2 = mysqli_prepare($kon, "INSERT INTO itc_pn (part_number, itc, description) VALUES (?, ?, ?)");
            if (!$stmt2) { $importErrors[] = "Row $row: prepare itc_pn failed: " . mysqli_error($kon); continue; }
            mysqli_stmt_bind_param($stmt2, "sss", $pn, $itc, $desc);
            if (!mysqli_stmt_execute($stmt2)) { $importErrors[] = "Row $row: insert itc_pn failed: " . mysqli_stmt_error($stmt2); }
            mysqli_stmt_close($stmt2);
          }

          $importedCount++;
        }
        if (empty($importErrors)) {
          echo '<div id="success-msg" class="card" style="border-left:4px solid #27ae60;margin-bottom:12px;"><div style="color:#155724;padding:6px 0">Import berhasil! ' . $importedCount . ' produk telah ditambahkan.</div></div>';
          echo '<script>document.getElementById("part_number").focus(); setTimeout(() => { document.getElementById("success-msg").style.display = "none"; }, 5000);</script>';
        } else {
          $errors[] = 'Import selesai dengan ' . count($importErrors) . ' error. ' . $importedCount . ' produk berhasil diimport. Error: ' . implode('; ', array_slice($importErrors,0,3));
        }
      } catch (Exception $e) {
        $errors[] = 'Gagal membaca file Excel: ' . $e->getMessage();
      }
    }
  } else {
    $errors[] = 'Format file tidak didukung. Hanya CSV, XLS, XLSX.';
  }
  }
}
        // Fixed categories list
               $categories = [
                        'Engine',
                        'Electrical',
                        'Brake System',
                        'Cylinder',
                        'Axle & Stering',
                        'Cabin',
                        'Filter',
                        'Attachment',
                        'Final Drive',
                        'Hydraulic System',
                    ];

                // current selection (preserve after submit)
                $selectedCategory = '';
                if (isset($_POST['category'])) $selectedCategory = trim($_POST['category']);
                elseif (isset($category) && $category !== '') $selectedCategory = $category;

                // preserve selected brand
                $selectedBrand = '';
                if (isset($_POST['brand'])) $selectedBrand = trim($_POST['brand']);
                elseif (isset($brand) && $brand !== '') $selectedBrand = $brand;

if(defined('IN_DASHBOARD')) { ?>
<?php if (!empty($errors)): ?>
        <div class="card" style="border-left:4px solid #e74c3c;margin-bottom:12px;">
          <?php foreach ($errors as $err): ?>
            <div style="color:#8a1f1f;padding:6px 0"><?php echo htmlspecialchars($err); ?></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
  <!-- Hanya tampilkan form saja -->
  <h2>Tambah Product</h2>
   <div class="container-fluid p-2 card-inner" style="background:#fff; box-shadow:0 2px 8px #2563eb22; height:700px;">
      
    <form method="POST" enctype="multipart/form-data" class="card form">
      <div class="row-two">
        <div class="col">
          <div class="field-inline">
            <label for="part_number">Part Number</label>
            <input id="part_number" class="input" type="text" name="part_number" required>
          </div>
        </div>
        <div class="col">
          <div class="field-inline">
            <label for="itc">Interchange</label>
            <input id="itc" class="input" type="text" name="itc">
          </div>
        </div>
      </div>

      <div class="form-row">
        <div class="field-inline field-multiline">
          <label for="description">Description</label>
          <textarea id="description" class="input" name="description" rows="4"></textarea>
        </div>
      </div>

      <div class="row-two">
        <div class="col">
          <div class="field-inline">
            <label for="brand">Brand</label>
            <select id="brand" class="input" name="brand" required>
            <option value="">-- Pilih brand --</option>
            <?php
              $brands = [
                'Komatsu', 'Bomag', 'Caterpillar', 'Scania', 'Volvo', 'Hyva', 'Other',
              ];
              foreach ($brands as $b):
            ?>
              <option value="<?php echo htmlspecialchars($b); ?>" <?php if ($selectedBrand === $b) echo 'selected'; ?>><?php echo htmlspecialchars($b); ?></option>
            <?php endforeach; ?>
          </select>
            </select>
          </div>
        </div>
        <div class="col">
          <div class="field-inline">
            <label for="category">Category</label>
            <select id="category" class="input" name="category" required>
            <option value="">-- Pilih category --</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?php echo htmlspecialchars($c); ?>" <?php if ($selectedCategory === $c) echo 'selected'; ?>><?php echo htmlspecialchars($c); ?></option>
            <?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>

      <div class="row-two">
        <div class="col">
          <div class="field-inline">
            <label for="qty">Quantity</label>
            <input id="qty" class="input" type="number" name="qty" min="0" required>
          </div>
        </div>
        <div class="col">
          <div class="field-inline">
            <label for="berat">Berat</label>
            <input id="berat" class="input" type="number" name="berat" min="0" required>
          </div>
        </div>
      </div>

      <div class="form-row">
        <label for="image">Image Product (opsional, JPG/PNG/GIF max 3MB)</label>
        <input id="image" class="input" type="file" name="image" accept="image/jpeg,image/png,image/gif,image/*">
        <div style="margin-top:8px;">
          <img id="fotoPreview" src="" alt="Preview foto" class="thumbnail" style="display:none;">
        </div>
      </div>

      <div class="form-actions">
        <button class="btn btn-add" type="submit" name="submit">Simpan</button>
        <button class="btn" type="reset">Reset</button>
        <a class="btn" href="?menu=product">Kembali</a>
      </div>
      
      
    </form>
  
 </div>

  <script>
  // Preview image
  (function(){
    var f = document.getElementById('image'), p = document.getElementById('fotoPreview');
    if(!f) return;
    f.addEventListener('change', function(){
      var file = this.files && this.files[0];
      if(!file){ p.style.display='none'; p.src=''; return; }
      if(!/^image\//.test(file.type)){ p.style.display='none'; p.src=''; return; }
      var reader = new FileReader();
      reader.onload = function(e){ p.src = e.target.result; p.style.display='block'; };
      reader.readAsDataURL(file);
    });
  })();

  // File info for import
  (function(){
    var fileInput = document.getElementById('file');
    var fileInfo = document.getElementById('file-info');
    if(!fileInput || !fileInfo) return;

    fileInput.addEventListener('change', function(){
      var file = this.files && this.files[0];
      if(!file){
        fileInfo.textContent = '';
        return;
      }

      var size = (file.size / 1024 / 1024).toFixed(2);
      var type = file.name.split('.').pop().toUpperCase();
      fileInfo.textContent = 'File: ' + file.name + ' | Size: ' + size + ' MB | Type: ' + type;

      // Basic validation
      var maxSize = type === 'CSV' ? 10 : 50; // 10MB for CSV, 50MB for Excel
      if(size > maxSize){
        fileInfo.style.color = '#e74c3c';
        fileInfo.textContent += ' ⚠️ File terlalu besar (max ' + maxSize + 'MB)';
      } else {
        fileInfo.style.color = '#27ae60';
        fileInfo.textContent += ' ✅ File siap diupload';
      }
    });
  })();

  // Force download for browsers that don't support download attribute
  (function(){
    var downloadLinks = document.querySelectorAll('a[href*="download.php"]');
    downloadLinks.forEach(function(link){
      link.addEventListener('click', function(e){
        // PHP script handles the download, but add visual feedback
        this.style.opacity = '0.7';
        setTimeout(() => { this.style.opacity = '1'; }, 1000);
      });
    });
  })();
  </script>
    <script>
    document.addEventListener('DOMContentLoaded', function(){
      if (<?php echo $focusPartNumber ? 'true' : 'false'; ?>) {
        var pn = document.getElementById('part_number');
        if (pn) { pn.focus(); pn.scrollIntoView({behavior:'smooth', block:'center'}); }
      }
    });
    </script>
  <?php
  return;
}
?>
</div>
  <?php // footer removed: managed by menu_admin shell ?>

</body>
  </html>