<?php
include(__DIR__ . '/../../../System/kon.php');
// Keep session available but do not redirect here; shell manages auth and header/footer
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if (!function_exists('include_fragment')) {
function include_fragment($path){
  if (!file_exists($path)) return '<div style="padding:1rem;color:#900">File not found: '.htmlspecialchars($path).'</div>';
  ob_start();
  include $path;
  $c = ob_get_clean();
  if (preg_match('#<body[^>]*>(.*)</body>#is', $c, $m)) return $m[1];
  if (preg_match('#<main[^>]*>(.*)</main>#is', $c, $m)) return $m[1];
  return $c;
}
}

function tampilkan_product() {
        global $kon;
        echo '<div class="top">';
        echo '<h2>Daftar Product</h2>';
        echo '<a class="btn btn-add" href="?menu=add">Tambah Product</a>';
        echo '</div>';
        echo '<table class="table">';
        echo '<tr>'
      . '<th style="width: 20px;">#</th>'
      . '<th style="width: 40px;">No</th>'
      . '<th style="width: 90px;">Part Number</th>'
      . '<th style="width: 90px;">Interchange</th>'
      . '<th style="width:200px;">Description</th>'
      . '<th style="width:70px;">Brand</th>'
      . '<th style="width:70px;">Category</th>'
      . '<th style="width:70px;">Qty</th>'
      . '<th style="width:70px;">Berat</th>'
      . '<th style="width:110px;">Image</th>'
      . '<th style="width:120px;">Action</th>'
      . '</tr>';
        $query = mysqli_query($kon, "SELECT * FROM Product ORDER BY `No` DESC");
        $row = 1;
        while($data = mysqli_fetch_assoc($query)){
          echo '<tr>';
          echo '<td style="width: 70px;">' . $row++ . '</td>';
          echo '<td style="width: 70px;">' . htmlspecialchars($data['No']) . '</td>';
          echo '<td>' . htmlspecialchars($data['part_number']) . '</td>';
          echo '<td>' . htmlspecialchars($data['itc']) . '</td>';
          echo '<td>' . htmlspecialchars($data['description']) . '</td>';
          echo '<td>' . htmlspecialchars($data['brand']) . '</td>';
          echo '<td>' . htmlspecialchars($data['category']) . '</td>';
          echo '<td>' . htmlspecialchars($data['Qty']) . '</td>';
          echo '<td>' . htmlspecialchars($data['berat'] ?? '') . '</td>';
          echo '<td>';
          if (!empty($data['image'])) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_buffer($finfo, $data['image']) : 'image/jpeg';
            if ($finfo) finfo_close($finfo);
            echo '<img src="data:' . htmlspecialchars($mime) . ';base64,' . base64_encode($data['image']) . '" alt="img" style="max-height:50px;border-radius:2px;">';
          } else {
            echo '-';
          }
          echo '</td>';
          echo '<td>';
          echo '<div style="display:flex; gap: 2px; align-items: left;">';
          $viewUrl = '?menu=view&no=' . urlencode($data['No']);
          $editUrl = '?menu=edit&no=' . urlencode($data['No']);
          echo '<a class="btn btn-view" href="' . htmlspecialchars($viewUrl, ENT_QUOTES) . '" title="Lihat" aria-label="Lihat">';
          echo '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
          echo '</a>';
          echo '<a class="btn btn-edit" href="' . htmlspecialchars($editUrl, ENT_QUOTES) . '">Edit</a>';
          // show delete only to Owner (B) and Dev (C)
          $showDelete = !empty($_SESSION['role']) && in_array($_SESSION['role'], ['B','C']);
          if ($showDelete) {
            $delUrl = '../../Control/product/Actions/del_prod.php?no=' . urlencode($data['No']);
            echo '<a class="btn btn-delete" data-no-ajax href="' . htmlspecialchars($delUrl, ENT_QUOTES) . '" onclick="return confirm(\'Yakin hapus?\')">Hapus</a>';
          }
          echo '</div>';
          echo '</td>';
          echo '</tr>';
        }
        echo '</table>';
      }
      // Render only the fragment content (no header/footer). The shell (`menu_admin.php`) will embed this.
      tampilkan_product();
      ?>
