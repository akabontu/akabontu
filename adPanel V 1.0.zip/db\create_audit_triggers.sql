-- Audit table and triggers for Product and itc_pn
-- Run this on your MySQL/MariaDB server (use the database for adpanel)

CREATE TABLE IF NOT EXISTS audit_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  table_name VARCHAR(100) NOT NULL,
  action ENUM('INSERT','UPDATE','DELETE') NOT NULL,
  pk_name VARCHAR(100),
  pk_value VARCHAR(255),
  old_data JSON,
  new_data JSON,
  changed_by VARCHAR(100) DEFAULT (SUBSTRING_INDEX(USER(),'@',1)),
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DELIMITER $$

-- Product: AFTER INSERT
CREATE TRIGGER tr_Product_after_insert
AFTER INSERT ON Product
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (table_name, action, pk_name, pk_value, old_data, new_data, changed_by)
  VALUES (
    'Product', 'INSERT', 'No', CAST(NEW.No AS CHAR),
    NULL,
    JSON_OBJECT(
      'part_number', NEW.part_number,
      'description', NEW.description,
      'itc', NEW.itc,
      'itc_1', NULL,
      'itc_2', NULL,
      'itc_3', NULL,
      'image', IF(NEW.image IS NULL, NULL, TO_BASE64(NEW.image))
    ),
    SUBSTRING_INDEX(USER(),'@',1)
  );
END$$

-- Product: AFTER UPDATE
CREATE TRIGGER tr_Product_after_update
AFTER UPDATE ON Product
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (table_name, action, pk_name, pk_value, old_data, new_data, changed_by)
  VALUES (
    'Product', 'UPDATE', 'No', CAST(NEW.No AS CHAR),
    JSON_OBJECT(
      'part_number', OLD.part_number,
      'description', OLD.description,
      'itc', OLD.itc,
      'itc_1', NULL,
      'itc_2', NULL,
      'itc_3', NULL,
      'image', IF(OLD.image IS NULL, NULL, TO_BASE64(OLD.image))
    ),
    JSON_OBJECT(
      'part_number', NEW.part_number,
      'description', NEW.description,
      'itc', NEW.itc,
      'itc_1', NULL,
      'itc_2', NULL,
      'itc_3', NULL,
      'image', IF(NEW.image IS NULL, NULL, TO_BASE64(NEW.image))
    ),
    SUBSTRING_INDEX(USER(),'@',1)
  );
END$$

-- Product: AFTER DELETE
CREATE TRIGGER tr_Product_after_delete
AFTER DELETE ON Product
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (table_name, action, pk_name, pk_value, old_data, new_data, changed_by)
  VALUES (
    'Product', 'DELETE', 'No', CAST(OLD.No AS CHAR),
    JSON_OBJECT(
      'part_number', OLD.part_number,
      'description', OLD.description,
      'itc', OLD.itc,
      'itc_1', NULL,
      'itc_2', NULL,
      'itc_3', NULL,
      'image', IF(OLD.image IS NULL, NULL, TO_BASE64(OLD.image))
    ),
    NULL,
    SUBSTRING_INDEX(USER(),'@',1)
  );
END$$

-- itc_pn: AFTER INSERT
CREATE TRIGGER tr_itc_pn_after_insert
AFTER INSERT ON itc_pn
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (table_name, action, pk_name, pk_value, old_data, new_data, changed_by)
  VALUES (
    'itc_pn', 'INSERT', 'no', CAST(NEW.no AS CHAR),
    NULL,
    JSON_OBJECT(
      'part_number', NEW.part_number,
      'description', NEW.description,
      'itc', NEW.itc,
      'itc_1', NEW.itc_1,
      'itc_2', NEW.itc_2,
      'itc_3', NEW.itc_3,
      'image', NULL
    ),
    SUBSTRING_INDEX(USER(),'@',1)
  );
END$$

-- itc_pn: AFTER UPDATE
CREATE TRIGGER tr_itc_pn_after_update
AFTER UPDATE ON itc_pn
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (table_name, action, pk_name, pk_value, old_data, new_data, changed_by)
  VALUES (
    'itc_pn', 'UPDATE', 'no', CAST(NEW.no AS CHAR),
    JSON_OBJECT(
      'part_number', OLD.part_number,
      'description', OLD.description,
      'itc', OLD.itc,
      'itc_1', OLD.itc_1,
      'itc_2', OLD.itc_2,
      'itc_3', OLD.itc_3,
      'image', NULL
    ),
    JSON_OBJECT(
      'part_number', NEW.part_number,
      'description', NEW.description,
      'itc', NEW.itc,
      'itc_1', NEW.itc_1,
      'itc_2', NEW.itc_2,
      'itc_3', NEW.itc_3,
      'image', NULL
    ),
    SUBSTRING_INDEX(USER(),'@',1)
  );
END$$

-- itc_pn: AFTER DELETE
CREATE TRIGGER tr_itc_pn_after_delete
AFTER DELETE ON itc_pn
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (table_name, action, pk_name, pk_value, old_data, new_data, changed_by)
  VALUES (
    'itc_pn', 'DELETE', 'no', CAST(OLD.no AS CHAR),
    JSON_OBJECT(
      'part_number', OLD.part_number,
      'description', OLD.description,
      'itc', OLD.itc,
      'itc_1', OLD.itc_1,
      'itc_2', OLD.itc_2,
      'itc_3', OLD.itc_3,
      'image', NULL
    ),
    NULL,
    SUBSTRING_INDEX(USER(),'@',1)
  );
END$$

DELIMITER ;

-- Notes:
-- 1) This implementation logs JSON for `old_data` and `new_data` with keys:
--    part_number, description, itc, itc_1, itc_2, itc_3, image.
-- 2) For `Product` the triggers will store the `image` as base64 string (useful for small images).
-- 3) To apply: from command line run:
--    mysql -u youruser -p your_database < db/create_audit_triggers.sql
