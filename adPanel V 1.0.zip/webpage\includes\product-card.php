<?php
// Partial: webpage/includes/product-card.php
// Expects $product array (or null) in scope
if (!isset($product)) {
    $product = null;
}
?>

<div class="card">
    <div class="product-thumb"style="height: 200px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
        <div class="image" style="height: 100%;"><a href="<?php echo $product ? 'webpage/pages/product_detail.php?part_number=' . urlencode($product['part_number']) : '#'; ?>">
            <?php if ($product && !empty($product['image'])): ?>
                <?php
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = $finfo ? finfo_buffer($finfo, $product['image']) : 'image/jpeg';
                if ($finfo) finfo_close($finfo);
                $imageDataUri = 'data:' . $mime . ';base64,' . base64_encode($product['image']);
                ?>
                <div class="product-thumb-overlay">
                    <img class="img-fluid" src="<?php echo htmlspecialchars($imageDataUri, ENT_QUOTES); ?>" alt="Foto <?php echo htmlspecialchars($product['part_number']); ?>">
                    <div class="overlay-label">CV. Magz Group</div>
                </div>
            <?php else: ?>
                <div class="no-image-lg">No Image</div>
            <?php endif; ?>
        </a></div>
    </div>
    <div class="content" style="padding:5px; ">
        <div style="flex:1; min-width:auto;">
            <div class="detail-row">
                <div class="detail-label" ><div class="detail-value" style="text-align:left; color:#e9ecef;"><h5 class="product-brand"style="color:#e9ecef;"><?php echo htmlspecialchars($product['brand'] ?? 'N/A'); ?></h5></div></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Part Number</div>
                <div class="detail-value" style="color:#e9ecef;"><?php echo htmlspecialchars($product['part_number'] ?? 'N/A'); ?></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Interchange</div>
                <div class="detail-value" style="color:#e9ecef;"><?php echo htmlspecialchars($product['itc'] ?? 'N/A'); ?></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Description</div>
                <div class="detail-value" style="color:#e9ecef;"><?php echo nl2br(htmlspecialchars($product['description'] ?? 'N/A')); ?></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Stock</div>
                <div class="detail-value" style="color:#e9ecef;"><?php echo htmlspecialchars($product['Qty'] ?? 'N/A'); ?></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Berat</div>
                <div class="detail-value" style="color:#e9ecef;"><?php echo htmlspecialchars($product['berat'] ?? 'N/A'); ?><span> Kg</span></div>
            </div>
            <div class="button-wa text-end">
                <a href="https://wa.me/6281110108000" class="btn-wa" target="_blank">Chat WhatsApp</a>
           </div>
        </div>
    </div>
</div>
