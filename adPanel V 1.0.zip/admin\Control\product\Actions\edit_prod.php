<?php
require_once __DIR__ . '/../../../System/kon.php';

$errors = [];

// Determine No from GET or POST
$no = 0;
if (isset($_GET['no'])) $no = intval($_GET['no']);
elseif (isset($_POST['no'])) $no = intval($_POST['no']);

if ($no <= 0) { header('Location: ../../../System/action/menu_admin.php?menu=product'); exit; }

// Fetch existing record
$stmt = mysqli_prepare($kon, "SELECT * FROM Product WHERE `No` = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $no);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
if (!$res || mysqli_num_rows($res) == 0) { header('Location: ../../../System/action/menu_admin.php?menu=product'); exit; }
$data = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

$part_number = $data['part_number'];

// Fixed categories list
$categories = [
    'Engine',
    'Electrical',
    'Brake System',
    'Cylinder',
    'Axle & Stering',
    'Cabin',
    'Filter',
    'Attachment',
    'Final Drive',
    'Hydraulic System',
];

// Selected category for the form (preserve POST on validation error)
$selectedCategory = isset($_POST['category']) ? trim($_POST['category']) : ($data['category'] ?? '');
// Selected brand for the form (preserve POST on validation error)
$selectedBrand = isset($_POST['brand']) ? trim($_POST['brand']) : ($data['brand'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
        // Preserve existing values if fields are disabled or not submitted
        $itc = isset($_POST['itc']) ? trim($_POST['itc']) : ($data['itc'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $brand = trim($_POST['brand'] ?? '');
        $category = trim($_POST['category'] ?? '');

        // For edit, ITC is not required since it's managed separately via the add button
        // if ($itc === '') $errors[] = 'Interchange harus diisi.';
        if ($description === '') $errors[] = 'Description harus diisi.';

        // Whitelist validation for brand and category
        $allowed_brands = ['Komatsu','Bomag','Caterpillar','Scania','Volvo','Hyva','Other'];
        $allowed_categories = [
            'Engine','Electrical','Brake System','Cylinder','Axle & Stering','Cabin','Filter','Attachment','Final Drive','Hydraulic System'
        ];
        if ($brand !== '' && !in_array($brand, $allowed_brands)) $errors[] = 'Brand tidak valid.';
        if ($category !== '' && !in_array($category, $allowed_categories)) $errors[] = 'Category tidak valid.';

        $imageData = null;
        if (!empty($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                $file = $_FILES['image'];
                if ($file['error'] !== UPLOAD_ERR_OK) {
                        $errors[] = 'Gagal mengupload image (kode ' . $file['error'] . ').';
                } else {
                        $allowed = ['image/jpeg','image/png','image/gif'];
                        $maxSize = 3 * 1024 * 1024;
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime = finfo_file($finfo, $file['tmp_name']);
                        finfo_close($finfo);
                        if (!in_array($mime, $allowed)) $errors[] = 'Tipe file tidak didukung.';
                        elseif ($file['size'] > $maxSize) $errors[] = 'Ukuran file terlalu besar (maks 3MB).';
                        else {
                                // Load and compress image if possible
                                $imageData = file_get_contents($file['tmp_name']);
                                if ($mime === 'image/jpeg' && function_exists('imagecreatefromjpeg')) {
                                        // Compress JPEG images
                                        $img = imagecreatefromjpeg($file['tmp_name']);
                                        if ($img) {
                                                ob_start();
                                                imagejpeg($img, null, 85); // 85% quality
                                                $imageData = ob_get_clean();
                                                imagedestroy($img);
                                        }
                                }
                        }
                }

            $stmt = mysqli_prepare($kon, "UPDATE Product SET itc=?, description=?, brand=?, category=?, image=? WHERE `No` = ?");
            $null = null;
            mysqli_stmt_bind_param($stmt, "ssssbi", $itc, $description, $brand, $category, $null, $no);
            mysqli_stmt_send_long_data($stmt, 4, $imageData);
            $ok = mysqli_stmt_execute($stmt);
            if (!$ok) {
              $errors[] = 'Gagal memperbarui data: ' . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
          } else {
            $stmt = mysqli_prepare($kon, "UPDATE Product SET itc=?, description=?, brand=?, category=? WHERE `No` = ?");
            mysqli_stmt_bind_param($stmt, "ssssi", $itc, $description, $brand, $category, $no);
            $ok = mysqli_stmt_execute($stmt);
            if (!$ok) {
              $errors[] = 'Gagal memperbarui data: ' . mysqli_stmt_error($stmt);
            }
              mysqli_stmt_close($stmt);
          }
          // jika itc dinput itu juga update ke itc_pn
          if ($itc !== '') { 
          $stmt2 = mysqli_prepare($kon, "INSERT INTO itc_pn (part_number, itc, description) VALUES (?, ?, ?)");
          if ($stmt2) {
              mysqli_stmt_bind_param($stmt2, "sss", $part_number, $itc, $description);
              $ok = mysqli_stmt_execute($stmt2);
              if (!$ok) {
                  $errors[] = 'Gagal menyimpan itc_pn: ' . mysqli_stmt_error($stmt2);
              }
              mysqli_stmt_close($stmt2);
          } else {
              $errors[] = 'Prepare itc_pn gagal: ' . mysqli_error($kon);
          }
          if (empty($errors)) {
              echo '<div id="success-msg" class="card" style="border-left:4px solid #27ae60;margin-bottom:12px;"><div style="color:#155724;padding:6px 0">Produk berhasil diperbarui!</div></div>';
              echo '<script>setTimeout(() => { window.location.href = "?menu=product"; }, 500);</script>';
          }
        }
        }



?>
<?php if (!defined('IN_DASHBOARD')): ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Edit Product</title>
  <link rel="stylesheet" href="../../../../assets/css/style.css">
</head>
<body>
<?php // header removed: managed by menu_admin shell ?>
<?php endif; ?>
    <?php if (!empty($errors)): ?>
      <div class="card" style="border-left:4px solid #e74c3c;margin-bottom:12px;">
        <?php foreach($errors as $err): ?><div style="color:#8a1f1f;padding:6px 0"><?php echo htmlspecialchars($err); ?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data" action="<?php echo defined('IN_DASHBOARD') ? '' : 'menu_admin.php?menu=edit&no=' . urlencode($no); ?>" class="card form">
      <input type="hidden" name="no" value="<?php echo htmlspecialchars($data['No']); ?>">
      <div class="form-row">
        <label for="part_number">Part Number</label>
        <input id="part_number" class="input" type="text" name="part_number" value="<?php echo htmlspecialchars($data['part_number']); ?>" disabled>
      </div>
      <div class="form-row">
        <label for="itc">Interchange</label>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
          <input
            id="itc"
            class="input"
            type="text"
            name="itc"
            value="<?php echo htmlspecialchars($data['itc'] ?? ''); ?>"
            style="max-width:260px;"
            <?php echo !empty($data['itc']) ? 'disabled' : ''; ?>
          >
          <button
            class="btn btn-import"
            type="button"
            id="btnAddItc"
            <?php echo empty($data['itc']) ? 'disabled' : ''; ?>
          >add</button>
          
		</div>
      </div>
      <div class="form-row">
        <label for="description">Description</label>
        <textarea id="description" class="input" name="description" rows="3"><?php echo htmlspecialchars($data['description']); ?></textarea>
      </div>
      <div class="form-row">
        <label for="brand">Brand</label>
        <select id="brand" class="input" name="brand">
          <option value="">-- Pilih brand --</option>
          <?php
            $brands = ['Komatsu','Bomag','Caterpillar','Scania','Volvo','Hyva','Other'];
            foreach ($brands as $b):
          ?>
            <option value="<?php echo htmlspecialchars($b); ?>" <?php if ($selectedBrand === $b) echo 'selected'; ?>><?php echo htmlspecialchars($b); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label for="category">Category</label>
        <select id="category" class="input" name="category">
          <option value="">-- Pilih category --</option>
          <?php foreach ($categories as $c): ?>
            <option value="<?php echo htmlspecialchars($c); ?>" <?php if ($selectedCategory === $c) echo 'selected'; ?>><?php echo htmlspecialchars($c); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Gambar Saat Ini</label>
        <?php if (!empty($data['image'])):
          $finfo = finfo_open(FILEINFO_MIME_TYPE);
          $mime = $finfo ? finfo_buffer($finfo, $data['image']) : 'image/jpeg';
          if ($finfo) finfo_close($finfo);
          $src = 'data:' . htmlspecialchars($mime) . ';base64,' . base64_encode($data['image']);
        ?>
        <img src="<?php echo $src; ?>" alt="Image" class="thumbnail">
        <?php else: ?>
          <div class="thumbnail" style="background:#f3f4f6;display:flex;align-items:center;justify-content:center;color:#9ca3af">No Image</div>
        <?php endif; ?>
        <label for="image">Ganti Image (opsional, JPG/PNG/GIF max 3MB)</label>
        <input id="image" class="input" type="file" name="image" accept="image/*">
        <img id="preview" class="thumbnail" src="" style="display:none;margin-top:8px;">
      </div>
      <div class="form-actions">
        <button class="btn btn-edit" type="submit" name="update">Update</button>
        <a class="btn" href="?menu=product">Batal</a>
      </div>
    </form>
<?php if(!defined('IN_DASHBOARD')): ?>
  </main>
</div>
<?php endif; ?>
<script>
// Preview image
(function(){
  var imgInput = document.getElementById('image');
  var preview = document.getElementById('preview');
  if (!imgInput) return;
  imgInput.addEventListener('change', function(e){
    var f = this.files && this.files[0];
    if (!f) { if(preview){ preview.style.display='none'; preview.src=''; } return; }
    if (!/^image\//.test(f.type)) { if(preview){ preview.style.display='none'; preview.src=''; } return; }
    var r = new FileReader(); r.onload = function(ev){ if(preview){ preview.src = ev.target.result; preview.style.display='block'; } }; r.readAsDataURL(f);
  });
})();
</script>
<script>
// Tombol add ITC
document.addEventListener('DOMContentLoaded', function() {
  var itcInput = document.getElementById('itc');
  var btnAdd = document.getElementById('btnAddItc');
  var partNumber = document.getElementById('part_number').value.trim();

  // Jika ITC kosong, enable input dan disable tombol
  if (itcInput && btnAdd) {
    console.log('ITC value:', itcInput.value.trim()); // Debug log
    if (!itcInput.value.trim()) {
      itcInput.disabled = false;
      btnAdd.disabled = true;
      console.log('ITC empty - input enabled, button disabled'); // Debug log
      itcInput.addEventListener('input', function() {
        if (itcInput.value.trim()) {
          btnAdd.disabled = false;
        } else {
          btnAdd.disabled = true;
        }
      });
    }

    btnAdd.addEventListener('click', function() {
      var itc = itcInput.value.trim();
      if (!itc) return;
      var noField = document.querySelector('input[name="no"]');
      var noVal = noField ? noField.value : '';
      // Open the edit ITC form inside dashboard
      var url = '?menu=edit_itc&itc=' + encodeURIComponent(itc) + '&part_number=' + encodeURIComponent(partNumber) + (noVal ? '&no=' + encodeURIComponent(noVal) : '');
      console.log('Redirecting to:', url); // Debug log
      window.location.href = url;
    });
  }
});
</script>
</body>
</html>
