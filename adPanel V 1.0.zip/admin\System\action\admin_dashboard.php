<?php
// admin_dashboard_old.php — legacy dashboard cleared.
// Kept as a placeholder to avoid accidental use; content removed.
return;
?>
