<!DOCTYPE html>
<html lang="en"data-bs-theme="dark">
<head>
    <title>Product Detail - Bootstrap 5 Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../css/combined.css">
    <style>
        /* Increase font sizes for product details for better readability */
        .product-info { font-size: 1.125rem; display: flex; flex-direction: column; height: 100%; }
        .product-info h2 { font-size: 1.6rem; margin-bottom: .75rem; }
        /* Spacing and separators to match card rhythm */
        .product-info dl { margin-bottom: 0; }
        .product-info dt { font-weight: 600; color: #d1d5db; padding: .6rem 0; }
        .product-info dd { font-size: 1.125rem; padding: .6rem 0; margin-bottom: 0; }
        .product-info dt, .product-info dd { border-bottom: 1px solid rgba(255,255,255,0.04); }
        .product-info dd:last-child { border-bottom: none; padding-bottom: .75rem; }
        .product-info .btn-row { margin-top: auto; }
        @media (min-width: 768px) {
            .product-info dd { font-size: 1.25rem; }
        }
    </style>
</head>
<body>
<?php
include '../../admin/System/kon.php';

// Get part_number from URL
$part_number = $_GET['part_number'] ?? '';
if (empty($part_number)) {
    die('Product not found.');
}

// Fetch product details
$part_number = mysqli_real_escape_string($kon, $part_number);
$query = "SELECT * FROM Product WHERE part_number = '$part_number'";
$result = mysqli_query($kon, $query);
if (!$result || mysqli_num_rows($result) == 0) {
    die('Product not found.');
}
$product = mysqli_fetch_assoc($result);
mysqli_free_result($result);

// Fetch interchanges from itc_pn table
$query_itc = "SELECT * FROM itc_pn WHERE part_number = '$part_number'";
$result_itc = mysqli_query($kon, $query_itc);
$itc_pn = mysqli_fetch_assoc($result_itc);
if ($result_itc) mysqli_free_result($result_itc);

// Fetch distinct brands for menu
$brands = [
    'Komatsu',
    'Bomag',
    'Caterpillar',
    'Scania',
    'Volvo',
    'Hyva',
    'Other',
];

// Fixed categories list
$categories = [
    'Engine',
    'Electrical',
    'Brake System',
    'Cylinder',
    'Axle & Stering',
    'Cabin',
    'Filter',
    'Attachment',
    'Final Drive',
    'Hydraulic System',
];

// Build menu data: each brand has the same categories
$menuData = [];
foreach ($brands as $brand) {
    $menuData[$brand] = $categories;
}
?>
    <?php
    // Ensure menu links point back to root index from this subfolder
    $menuIndexPath = '../../index.php';
    include '../includes/header.php';
    ?>

    <!-- Product Detail -->
    <div class="container mt-4">
        <div class="row align-items-stretch">
            <div class="col-md-6">
                <div class="product-image" style="height: 100%;">
                    <?php if (!empty($product['image'])): ?>
                        <?php
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime = $finfo ? finfo_buffer($finfo, $product['image']) : 'image/jpeg';
                        if ($finfo) finfo_close($finfo);
                        $imageDataUri = 'data:' . $mime . ';base64,' . base64_encode($product['image']);
                        ?>
                        <div class="product-image-overlay">
                            <img src="<?php echo htmlspecialchars($imageDataUri, ENT_QUOTES); ?>" alt="Product Image" class="img-fluid">
                            <div class="overlay-label">CV. Magz Group</div>
                        </div>
                    <?php else: ?>
                        <div class="no-image-detail">No Image Available</div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="p-3 bg-dark text-light rounded product-info">
                    <h2 class="h4 mb-3"><?php echo htmlspecialchars($product['brand'] ?? 'N/A'); ?></h2>

                    <dl class="row mb-0 gx-0 align-items-start">
                        <dt class="col-sm-3 text-sm-start ps-0 pe-2">Part Number</dt>
                        <dd class="col-sm-9 mb-2 ps-sm-3 ps-0"><?php echo htmlspecialchars($product['part_number'] ?? 'N/A'); ?></dd>

                        <dt class="col-sm-3 text-sm-start ps-0 pe-2">Interchange</dt>
                        <dd class="col-sm-9 mb-2 ps-sm-3 ps-0">
                            <?php
                            $parts = [];
                            if (!empty($product['itc'])) $parts[] = $product['itc'];
                            if (!empty($itc_pn['itc_1'])) $parts[] = $itc_pn['itc_1'];
                            if (!empty($itc_pn['itc_2'])) $parts[] = $itc_pn['itc_2'];
                            if (!empty($itc_pn['itc_3'])) $parts[] = $itc_pn['itc_3'];
                            echo htmlspecialchars(implode(', ', $parts) ?: 'N/A');
                            ?>
                        </dd>

                        <dt class="col-sm-3 text-sm-start ps-0 pe-2">Description</dt>
                        <dd class="col-sm-9 mb-2 ps-sm-3 ps-0"><?php echo nl2br(htmlspecialchars($product['description'] ?? 'N/A')); ?></dd>

                        <dt class="col-sm-3 text-sm-start ps-0 pe-2">Stock</dt>
                        <dd class="col-sm-9 mb-2 ps-sm-3 ps-0"><?php echo htmlspecialchars($product['Qty'] ?? 'N/A'); ?></dd>

                        <dt class="col-sm-3 text-sm-start ps-0 pe-2">Berat</dt>
                        <dd class="col-sm-9 mb-2 ps-sm-3 ps-0"><?php echo htmlspecialchars($product['berat'] ?? 'N/A'); ?> Kg</dd>
                    </dl>

                    <div class="btn-row">
                        <a href="https://wa.me/6281110108000?text=I'm interested in product <?php echo urlencode($product['part_number']); ?>" class="btn btn-success me-2" target="_blank">Contact via WhatsApp</a>
                        <a href="../../index.php" class="btn btn-secondary">Back to Product List</a>
                    </div>
                </div>
            </div>
    </div>

  
</body>
  <?php include '../includes/footer.php'; ?>
</html>